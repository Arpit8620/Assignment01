const fieldConstants = {
  TEXT: "text",
  TEXTAREA: "textarea",
  DROPDOWN: "dropdown",
  RADIOBUTTON: "radio",
  CHECKBOX: "checkbox",
};

const HEADER_BUTTONS = {
  ADD: "Add",
  REMOVE: "Remove",
};

export { fieldConstants, HEADER_BUTTONS };
