import { fieldConstants } from "../../constants/fields.constants";

const getCorrespondingInputField = ({
  inputType = "text",
  fieldOptions = [],
  ...otherOptions
}) => {
  switch (inputType) {
    case fieldConstants.DROPDOWN:
      return (
        <select {...otherOptions}>
          {fieldOptions?.map((val) => {
            return <option value={val}>{val.toUpperCase()}</option>;
          })}
        </select>
      );
    case fieldConstants.CHECKBOX:
    case fieldConstants.RADIOBUTTON:
      return fieldOptions?.map(({ id, value, ...rest }) => {
        return (
          <>
            <input type={inputType} id={id} {...rest} {...otherOptions} />
            <label for={id}>{value}</label>
            <br />
          </>
        );
      });
  }
  return <input type={inputType} {...otherOptions} />;
};

export { getCorrespondingInputField };
