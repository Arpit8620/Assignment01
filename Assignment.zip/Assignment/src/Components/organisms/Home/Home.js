import React from "react";
import BaseForm from "../../molecules/BaseForm/BaseForm";

const Home = () => {
  return <BaseForm />;
};

Home.propTypes = {};

Home.defaultProps = {};

export default Home;
