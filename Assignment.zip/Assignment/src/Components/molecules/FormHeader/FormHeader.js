import React from "react";
import cx from "classnames";

import styles from "./formHeader.module.css";

const FormHeader = ({ addFields, formState }) => {
  const handleButtonClick = (event) => {
    event?.preventDefault();
    addFields(event?.target?.textContent);
  };

  return (
    <div className={styles.formContainer}>
      <span>Dynamic Form</span>
      <div>
        <button
          className={cx(styles.addButton, {
            [styles.disabledButton]: formState,
          })}
          onClick={handleButtonClick}
        >
          Remove
        </button>
        <button className={styles.addButton} onClick={handleButtonClick}>
          Add
        </button>
      </div>
    </div>
  );
};

FormHeader.propTypes = {};

FormHeader.defaultProps = {};

export default FormHeader;
