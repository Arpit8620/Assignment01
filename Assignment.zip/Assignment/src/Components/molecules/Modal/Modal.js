import React, { useMemo } from "react";
import cx from "classnames";

import AddModule from "../AddModule/AddModule.js";
import { getModalInnerValues } from "./modal.helper.js";

import styles from "./modal.module.css";

const Modal = ({ type, closeModal, ...rest }) => {
  const { Component, ...restValues } = useMemo(
    () => getModalInnerValues(type),
    []
  );
  return (
    <div className={styles.modalContainer}>
      <div className={styles.modalHeader}>
        <label className={styles.heading}>Add Form Fields</label>
        <div className={styles.cancelIcon} onClick={closeModal}>
          <span className={cx(styles.cancelStick, styles.leftRotation)}></span>
          <span className={cx(styles.cancelStick, styles.rightRotation)}></span>
        </div>
      </div>

      <Component {...restValues} {...rest} closeModal={closeModal} />
    </div>
  );
};

export default Modal;
