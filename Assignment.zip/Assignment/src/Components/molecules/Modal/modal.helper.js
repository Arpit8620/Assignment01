import AddModule from "../AddModule/AddModule.js";

import RemoveModule from "../RemoveModule/RemoveModule.js";
import { HEADER_BUTTONS } from "../../../constants/fields.constants";

const getModalInnerValues = (values) => {
  switch (values) {
    case HEADER_BUTTONS.ADD:
      return { Component: AddModule };
    case HEADER_BUTTONS.REMOVE:
      return { Component: RemoveModule };
  }
};

export { getModalInnerValues };
