import React, { useState } from "react";
import cx from "classnames";

import DynamicForm from "../DynamicForm/DynamicForm.js";
import FormHeader from "../FormHeader/FormHeader.js";
import Modal from "../Modal/Modal.js";

import styles from "./baseForm.module.css";

const BaseForm = ({ formFields = [] }) => {
  const [modalStatus, setModalStatus] = useState("");
  const [currentFormFields, setCurrentFormFields] = useState(formFields);
  const [formValues, setFormValues] = useState({});

  const closeModal = () => {
    setModalStatus("");
  };

  const handleUpdateFormField = (fields, fullUpdate = false) => {
    if (!fullUpdate) {
      setCurrentFormFields([...currentFormFields, fields]);
    } else {
      setCurrentFormFields([...fields]);
    }
    closeModal();
  };

  return (
    <div
      className={cx(styles.baseFormContainer, {
        [styles.disabled]: modalStatus,
      })}
    >
      <FormHeader
        addFields={setModalStatus}
        formState={currentFormFields?.length == 0}
      />
      {currentFormFields?.length > 0 && (
        <DynamicForm
          currentFormFields={currentFormFields}
          setFormValues={setFormValues}
        />
      )}
      {modalStatus && (
        <Modal
          handleUpdateFormField={handleUpdateFormField}
          fields={currentFormFields}
          type={modalStatus}
          closeModal={closeModal}
        />
      )}
    </div>
  );
};

export default BaseForm;
