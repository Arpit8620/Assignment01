import React, { useState } from "react";
import { map } from "lodash";

import { getCorrespondingInputField } from "../../HelperComponents/formComponents.helper";

import styles from "./dynamicForm.module.css";

const DynamicForm = ({ currentFormFields, setFormValues: setForm }) => {
  const [formValues, setFormValues] = useState({});

  const handleFieldChange = ({ event, label }) => {
    setFormValues({
      ...formValues,
      [label]: event.target.value,
    });
  };

  const handleFormSubmit = (event) => {
    event.preventDefault();
    setForm({ formValues });
  };

  return (
    <div>
      <form className={styles.formContainer} onSubmit={handleFormSubmit}>
        {map(currentFormFields, ({ label, ...rest }) => {
          return (
            <div className={styles.row}>
              <label>{label} : </label>
              {getCorrespondingInputField({
                ...rest,
                className: styles.formField,
                onChange: (event) => handleFieldChange({ event, label }),
              })}
            </div>
          );
        })}
        <button type="submit" className={styles.submitButton}>
          Submit
        </button>
      </form>
    </div>
  );
};

export default DynamicForm;
