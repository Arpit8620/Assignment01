import { fieldConstants } from "../../../constants/fields.constants";

const getCurrentFormStatus = (currentField) => {
  return (
    currentField == fieldConstants.DROPDOWN ||
    currentField == fieldConstants.CHECKBOX ||
    currentField == fieldConstants.RADIOBUTTON
  );
};

export { getCurrentFormStatus };
