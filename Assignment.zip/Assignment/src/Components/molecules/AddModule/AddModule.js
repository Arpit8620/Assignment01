import React, { useState } from "react";

import { getCorrespondingInputField } from "../../HelperComponents/formComponents.helper";
import { fieldConstants } from "../../../constants/fields.constants";
import { DROPDOWN_OPTIONS } from "./addModule.constants";
import { getCurrentFormStatus } from "./addModule.helper.js";

import AddOptions from "../AddOptions/AddOptions.js";

import styles from "./addModule.module.css";

const AddModule = ({ handleUpdateFormField }) => {
  const [fieldType, setFieldType] = useState("");
  const [label, setLabel] = useState("");
  const [displayAddOptions, setDisplayAddOptions] = useState(false);
  const [fieldOptions, setFieldOptions] = useState([]);
  const [currentOptionField, setCurrentOptionField] = useState("");

  const handleLableUpdate = (event) => {
    setLabel(event.target.value);
  };

  const handleFieldSelection = (event) => {
    event.preventDefault();
    setDisplayAddOptions(getCurrentFormStatus(event.target.value));
    setFieldType(event.target.value);
    setFieldOptions([]);
  };

  const handleAddOptions = (event) => {
    setCurrentOptionField(event.target.value);
  };

  const handleFieldOptionsUpdate = (event) => {
    switch (fieldType) {
      case fieldConstants.RADIOBUTTON:
      case fieldConstants.CHECKBOX:
        setFieldOptions([
          ...fieldOptions,
          { value: currentOptionField, id: label },
        ]);
        break;
      case fieldConstants.DROPDOWN:
        setFieldOptions([...fieldOptions, currentOptionField]);
        break;
    }
    setCurrentOptionField("");
  };

  const handleFormSubmit = () => {
    handleUpdateFormField({ label, inputType: fieldType, fieldOptions });
  };

  return (
    <div className={styles.container}>
      <div>
        <label>Enter The Label : </label>
        {getCorrespondingInputField({
          inputType: fieldConstants.TEXT,
          onChange: handleLableUpdate,
          classNames: styles.row,
        })}
      </div>
      <div>
        <label> Select the Field Type : </label>
        {getCorrespondingInputField({
          inputType: fieldConstants.DROPDOWN,
          ...DROPDOWN_OPTIONS,
          onChange: handleFieldSelection,
          classNames: styles.row,
        })}
      </div>
      {displayAddOptions && (
        <div>
          <label>Enter The Options : </label>
          {getCorrespondingInputField({
            inputType: fieldConstants.TEXT,
            onChange: handleAddOptions,
            value: currentOptionField,
            classNames: styles.row,
          })}
          <button onClick={handleFieldOptionsUpdate}>Add Field</button>
        </div>
      )}
      {displayAddOptions && <AddOptions options={fieldOptions} />}
      <button onClick={handleFormSubmit} className={styles.addOption}>
        Add Field
      </button>
    </div>
  );
};

export default AddModule;
