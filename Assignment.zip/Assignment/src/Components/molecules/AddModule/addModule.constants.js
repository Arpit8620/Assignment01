import { fieldConstants } from "../../../constants/fields.constants";

const DROPDOWN_OPTIONS = {
  fieldOptions: Object.values(fieldConstants),
};

export { DROPDOWN_OPTIONS };
