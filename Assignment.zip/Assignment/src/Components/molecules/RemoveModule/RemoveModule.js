import React, { useLayoutEffect } from "react";
import cx from "classnames";

import styles from "./removeModule.module.css";

const RemoveModule = ({ fields = [], handleUpdateFormField, ...props }) => {
  const [formFields, setFormFields] = React.useState(fields);

  useLayoutEffect(() => {
    setFormFields(
      fields?.map((field, key) => {
        return { ...field, selected: false, id: key };
      })
    );
  }, []);

  const handleFieldSelection = (value) => {
    setFormFields(
      formFields?.map((field) => {
        if (field?.id === value) {
          return { ...field, selected: !field?.selected };
        }
        return field;
      })
    );
  };

  const handleDeleteField = (event) => {
    event.preventDefault();
    handleUpdateFormField(
      formFields?.filter((field) => !field?.selected),
      true
    );
  };

  return (
    <div className={styles.container}>
      <div>
        {formFields?.map(({ label, selected, id }) => {
          return (
            <div
              key={id}
              className={cx(styles.row, { [styles.selected]: selected })}
              onClick={() => handleFieldSelection(id)}
            >
              {label}
            </div>
          );
        })}
      </div>
      <button className={styles.button} onClick={handleDeleteField}>
        Remove
      </button>
    </div>
  );
};

export default RemoveModule;
