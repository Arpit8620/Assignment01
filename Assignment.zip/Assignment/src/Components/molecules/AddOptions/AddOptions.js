import React from "react";
import { map } from "lodash";

import styles from "./addOptions.module.css";

const AddOptions = ({ options }) => {
  return (
    <div className={styles.container}>
      {map(options, (option) => {
        return <div className={styles.options}>{option?.value || option}</div>;
      })}
    </div>
  );
};

AddOptions.propTypes = {};

AddOptions.defaultProps = {
  options: [],
};

export default AddOptions;
