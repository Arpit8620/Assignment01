import Home from "./Components/organisms/Home/Home";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Home />
    </div>
  );
}
